import jaydebeapi, sys

def customer_details():
  dsn_database = "BLUDB"
  dsn_hostname = "dashdb-entry-yp-syd01-01.services.au-syd.bluemix.net"
  dsn_port = "50000"
  dsn_uid = "dash33171"
  dsn_pwd = "_Qlx0fH6_RKa"

  connection_string = 'jdbc:db2://' + dsn_hostname + ':' + dsn_port + '/' + dsn_database
  if (sys.version_info >= (3, 0)):
    conn = jaydebeapi.connect("com.ibm.db2.jcc.DB2Driver", connection_string, [dsn_uid, dsn_pwd])
  else :
    conn = jaydebeapi.connect("com.ibm.db2.jcc.DB2Driver", [connection_string, dsn_uid, dsn_pwd])

  curs = conn.cursor()
  curs.execute("select c_first_name from customer where c_customer_sk=1753")
  print("all good")
  result_set = curs.fetchall()
  for row in result_set:
   print(row[0])
  curs.close()
  
def init():
    # Do nothing for now
  pass

customer_details()
