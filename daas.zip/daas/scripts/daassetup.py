import re, sys ,jaydebeapi
import json
def parseInput(obj):
  tableName=obj['tableName']
  filterCol=obj['filterCol']
  filterValue=str(obj['filterValue'])
  regex = re.compile('[@_!#$%^&*()<>?/\|}{~:]') 
  if(regex.search(filterValue) == None): 
    return(obj)
  else: 
    return 1 
    
  
def dbConnection():
  dsn_database = "BLUDB"
  dsn_hostname = "dashdb-entry-yp-syd01-01.services.au-syd.bluemix.net"
  dsn_port = "50000"
  dsn_uid = "dash33171"
  dsn_pwd = "_Qlx0fH6_RKa"
  connection_string = 'jdbc:db2://' + dsn_hostname + ':' + dsn_port + '/' + dsn_database
  #print("connection string created")
  if (sys.version_info >= (3, 0)):
    conn = jaydebeapi.connect("com.ibm.db2.jcc.DB2Driver", connection_string, [dsn_uid, dsn_pwd])
    return conn
  else :
    conn = jaydebeapi.connect("com.ibm.db2.jcc.DB2Driver", [connection_string, dsn_uid, dsn_pwd])
    return conn
    
def executeQuery(obj,outputfield):
  tableName=obj['tableName']
  filterCol=obj['filterCol']
  filterValue=(obj['filterValue'])
  conn1=dbConnection()
  curs = conn1.cursor()
  #print("cursor opened")
  query_string = 'select ' + outputfield  + ' from ' + tableName + ' where ' + filterCol +'=' + filterValue
  #print(query_string)
  curs.execute(query_string)
  #print("all good")
  result_set = curs.fetchall()
  for row in result_set:
   return row
  curs.close()
      

def parseOutput(jsonString):
  jsonObject = json.loads(jsonString)
    # print the keys and values
  selectColumn=""
  for key in jsonObject:
    value = jsonObject[key]
    selectColumn= selectColumn + value + ' , '
  selectColumn =selectColumn[:-2]
  return selectColumn
  
  
  
def test1():
  outf='{"col1":"c_first_name","col2":"C_LAST_NAME","col3":"c_email_address"}'
  outputColumn= parseOutput(outf)
  #print(outputColumn)
  inputp={"tableName": "customer", "filterCol": "c_customer_sk", "filterValue": "1753"}
  if (parseInput(inputp) ==1 ):
    print("input error")
  else :
    return(executeQuery(inputp,outputColumn) )
   


#parseOutput('{"key1":"value1","key2":"value2","key3":"value3"}')  
#executeQuery({"tableName": "customer", "filterCol": "c_customer_sk", "filterValue": "1753"})
