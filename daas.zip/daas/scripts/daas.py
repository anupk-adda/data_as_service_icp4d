from daassetup import *

def getCustomerDetails(custkey):
  outf='{"col1":"c_first_name","col2":"C_LAST_NAME","col3":"c_email_address"}'
  outputColumn= parseOutput(outf)
  #print(outputColumn)
  inputp={"tableName": "customer", "filterCol": "c_customer_sk", "filterValue": str(custkey)}
  if (parseInput(inputp) ==1 ):
    print("input error please try with correct filter critria")
  else :
    return executeQuery(inputp,outputColumn) 
    
  